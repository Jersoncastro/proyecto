
import match as m
sin=1
pi=3.14
opt=m.sin(m.pi/2)
print(opt)

