

def subtra (a,b):
    print(a - b)
    return(a-b)
subtra(5,2)
resultado=subtra(a=10,b=2)
opt=resultado+5
print(opt)

