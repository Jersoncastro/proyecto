
pi=22/7
print(pi)
print("{:.2f}".format(pi))
