# -*- coding: utf-8 -*-
"""
Created on Tue Jun 28 11:58:13 2022

@author: 
"""

matrix=[[0]*4]*4
matrix[0][0]=5
matrix[1][0]=10
