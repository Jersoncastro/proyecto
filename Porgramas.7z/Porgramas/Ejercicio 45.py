# -*- coding: utf-8 -*-
"""
Created on Tue Jun 28 11:47:24 2022

@author: bryan
"""

matriz2=[0]*4
for i in range(4):
    matriz2[i]=[0]*4
    
matriz2[0][3]=100
matriz2[3][0]=100