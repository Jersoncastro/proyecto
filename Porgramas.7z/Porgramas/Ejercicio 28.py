
from math import pi as mpi,sin as msin
sin=1
pi=3.14
print(msin(mpi/2))

