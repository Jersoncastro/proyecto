# -*- coding: utf-8 -*-
"""
Created on Tue Jun 28 11:07:36 2022

@author: 
"""

matrix=[[1,2,3,4],
       [4,5,6,7],
       [8,9,10,11]]

print(matrix[0][0])
print(matrix[2][2])

matrix[1][0]=10