# -*- coding: utf-8 -*-
"""
Created on Tue Jun 28 11:25:17 2022

@author: bryan
"""

matrix=[[1,2,3,4],
       [4,5,6,7],
       [8,9,10,11,12]]

print(matrix[0][0])
print(matrix[0][1])
print(matrix[0][2])
print(matrix[0][3])
print(matrix[1][0])
print(matrix[1][1])
print(matrix[1][2])
print(matrix[1][3])
print(matrix[2][0])
print(matrix[2][1])
print(matrix[2][2])
print(matrix[2][3])
print(matrix[2][4])