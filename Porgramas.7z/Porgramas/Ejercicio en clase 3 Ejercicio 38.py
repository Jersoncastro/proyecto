
N=[0]*7
for h in range(0,7):
 i=int(input("Ingrese un numero: "))
 N[h]=i
 
for h in range(7):
    print("El valor de",h,"de la lista es: ",N[h])
    