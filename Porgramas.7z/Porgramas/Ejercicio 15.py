
print("Ingrese un valor")
a=input()
print("Ingrese un valor")
b=input()
print("Ingrese un valor")
c=input()
print("Ingrese un valor")
d=input()
suma=a+b+c+d
print(suma)