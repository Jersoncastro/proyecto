
sumar= lambda num1,num2: num1+num2
restar= lambda num1,num2: num1-num2
multiplicar= lambda num1,num2: num1*num2
dividir= lambda num1,num2: num1/num2

print(sumar(3,8))
print(restar(10,9))
print(multiplicar(8,9))
print(dividir(25,5))
