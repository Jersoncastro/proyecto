
n1=input("Ingrese su ciudad: ")
n2=input("Ingrese su barrio: ")
n3=input("Ingrese su calle: ")
def direccion (n1,n2,n3):
    print("Su delivery esta listo enviando informacion a:",n1,"-",n2,"-",n3)
direccion(n1,n2,n3)
    