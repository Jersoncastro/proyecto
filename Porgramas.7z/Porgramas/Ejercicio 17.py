
n1=input("Ingrese el nombre que desea saludar: ")
n2=input("Ingrese el segundo nombre que desea saludar: ")
def Hola (n1,n2):
    print("Hola ",n1)
    print("Hola ",n2)
Hola(n1,n2)