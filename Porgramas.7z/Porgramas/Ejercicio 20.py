
def mult (a,b):
    return(a*b)
resultado=mult(a=2,b=6)
print(resultado)

