

vector=[0]*7

vector[0]=10
vector[1]=24
vector[2]=18
vector[3]=5
vector[4]=85
vector[5]=119
vector[6]=524

for i in range(7):
    print(vector[i])