
lista1=[5,58.8,"Cisco","Networking",True,False,12,8,85,5]
tupla1=(5,58.8,"Cisco","Networking",True,False,12,8,85.5)
print(lista1)
print("\n")
print(tupla1)
print("\n"*2)
print(lista1[0])
print("\n"*2)
print(lista1[8])
print(tupla1[0])
print(tupla1[8])
lista1[7]="Academy"
len(lista1)
del lista1[7]
print(lista1[-8])