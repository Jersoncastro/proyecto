
def suma(a,b):
    return(a+b)
resultado=suma(a=3,b=9)
print(resultado)

