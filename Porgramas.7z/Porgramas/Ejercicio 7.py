
dict1={"TELEFONO":"3962823",
        "CIUDAD":"QUITO",
        1:"7412589630",
        False:"Valor de verdad",
        85.5:"Tiempo de recorrido"}
print(dict1)
print(dict1[False])
