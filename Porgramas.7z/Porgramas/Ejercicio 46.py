# -*- coding: utf-8 -*-
"""
Created on Tue Jun 28 11:50:43 2022

@author: bryan
"""

fila=10
columna=10
matriz2=[0]*fila
for i in range(columna):
    matriz2[i]=[0]*columna
    
matriz2[0][3]=100
matriz2[3][0]=100