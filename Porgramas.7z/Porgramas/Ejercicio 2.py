
variable=5
palabra="Cisco"
expresion=palabra*variable
print(expresion)
print("\n"*2)
print("Otra linea")
print("\n"*3)
print("Hola Mundo")
