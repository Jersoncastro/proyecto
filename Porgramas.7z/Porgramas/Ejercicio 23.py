
def saludo (lista):
    for i in lista:
        print("Hola,",i)
    print(" ")
saludo(["Elmer "])
saludo(["Jose ","John "])
saludo(["Alex ","Tatiana ","Patricia "])        

