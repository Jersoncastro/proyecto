
def mensaje():
    print("Ingrese un numero entero")
    
mensaje()
a=input()
mensaje()
b=input()
mensaje()
c=input()
mensaje()
d=input()
suma=a+b+c+d
print(suma)