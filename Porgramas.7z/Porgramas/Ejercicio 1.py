
print(type(5))
print(type(5.85))
print(type("5"))
print(type(False))


