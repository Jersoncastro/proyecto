
def division (a,b):
    return(a/b)
resultado=division(a=10,b=3)
print(resultado)
