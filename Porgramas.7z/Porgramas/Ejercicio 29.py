
from match import *
opt=(sin(pi/2))
print(opt)

