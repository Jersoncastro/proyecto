


datos=[]
for i in range(7):
    n=int(input("Ingrese numeros de la lista: "))
    datos.append(n)
print(datos)