
str1="Cisco"
str2="Networking"
str3="Academy"
space=" "
print(str1+space+str2+space+str3)
print("\n"*2)
print(str1+str2+str3)
print("\n"*2)
print(str1,str2,str3)
